import './App.css';
function About() {

  return (
    <div className="aboutt">
			
			<p className='section'><br/><br/> The Shopper’s cart is a shopping website which is designed to order items through the browser. The website will provide users with the chance to register and login themselves. The website will provide different kinds of categories from where users can buy the products. Users can choose the products from the given categories and admin can add the products to cart. Once the product is added to the cart, the user can remove the product from the cart as well.  

They will be able to check the total of the added products in view cart option. Users can check out the products for order and can place the order by providing the delivery address. User registration and login feature is provided on the website.<br/> <br/>The shopkeepers can add or remove the products from website view according to the available stock. 

Existing Online shopping system allows consumers directly buy goods, services etc. From a seller without an intermediary service over the Internet.  

<br/>There are sample number of varieties available.  

Existing system saves time and efforts.  

Existing system provides convenience of shopping from home.   

Variety of goods are available in online. </p>

	</div>
  );
}

export default About;
