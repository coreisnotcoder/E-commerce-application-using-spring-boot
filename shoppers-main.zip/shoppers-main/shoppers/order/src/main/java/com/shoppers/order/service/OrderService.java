package com.shoppers.order.service;

import com.shoppers.order.model.Order;

public interface OrderService {
    public Order saveOrder(Order order);
}
