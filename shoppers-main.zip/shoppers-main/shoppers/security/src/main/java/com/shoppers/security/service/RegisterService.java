package com.shoppers.security.service;

import com.shoppers.security.model.ShopperUser;

public interface RegisterService {

	void createUser(ShopperUser user);

}
